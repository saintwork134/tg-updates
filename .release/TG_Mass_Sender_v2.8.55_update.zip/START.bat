@echo off
cd /d "%~dp0"

if exist "%~dp0Start.exe" (
    start "" /D "%~dp0" "%~dp0Start.exe"
    exit /b 0
)

if exist "%~dp0dist\Start.exe" (
    start "" /D "%~dp0" "%~dp0dist\Start.exe"
    exit /b 0
)

if exist "%~dp0dist\TG Mass Sender.exe" (
    start "" /D "%~dp0" "%~dp0dist\TG Mass Sender.exe"
    exit /b 0
)

set PYTHON=

if exist "%LocalAppData%\Python\pythoncore-3.14-64\python.exe" (
    set PYTHON=%LocalAppData%\Python\pythoncore-3.14-64\python.exe
    goto found
)
if exist "%LocalAppData%\Programs\Python\Python314\python.exe" (
    set PYTHON=%LocalAppData%\Programs\Python\Python314\python.exe
    goto found
)
if exist "%LocalAppData%\Programs\Python\Python313\python.exe" (
    set PYTHON=%LocalAppData%\Programs\Python\Python313\python.exe
    goto found
)
if exist "%LocalAppData%\Programs\Python\Python312\python.exe" (
    set PYTHON=%LocalAppData%\Programs\Python\Python312\python.exe
    goto found
)
if exist "%LocalAppData%\Programs\Python\Python311\python.exe" (
    set PYTHON=%LocalAppData%\Programs\Python\Python311\python.exe
    goto found
)
if exist "C:\Python314\python.exe" (
    set PYTHON=C:\Python314\python.exe
    goto found
)
if exist "C:\Python312\python.exe" (
    set PYTHON=C:\Python312\python.exe
    goto found
)

python --version >nul 2>&1
if %errorlevel%==0 (
    set PYTHON=python
    goto found
)

echo Python not found and compiled exe is missing.
echo Run dist\TG Mass Sender.exe or install Python: https://www.python.org/downloads/
pause
exit /b 1

:found
echo Compiled exe not found. Starting through Python fallback...
"%PYTHON%" -m pip install -r requirements.txt --quiet --no-warn-script-location
"%PYTHON%" main.py
if %errorlevel% neq 0 (
    echo Error! See details above.
    pause
)
